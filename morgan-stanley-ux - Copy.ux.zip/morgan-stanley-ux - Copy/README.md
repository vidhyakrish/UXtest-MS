# MorganStanleyUx


This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.5.5

# Please run 'npm install' after unzipping.

.

## 

Run `ng serve` for a dev server. 

Navigate to `http://localhost:4200/`

 